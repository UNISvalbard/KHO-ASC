/*******************************************************************************
* File Name: Watchdog.c  
* Version 3.0
*
*  Description:
*     The Counter component consists of a 8, 16, 24 or 32-bit counter with
*     a selectable period between 2 and 2^Width - 1.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Watchdog.h"

uint8 Watchdog_initVar = 0u;


/*******************************************************************************
* Function Name: Watchdog_Init
********************************************************************************
* Summary:
*     Initialize to the schematic state
* 
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void Watchdog_Init(void) 
{
        #if (!Watchdog_UsingFixedFunction && !Watchdog_ControlRegRemoved)
            uint8 ctrl;
        #endif /* (!Watchdog_UsingFixedFunction && !Watchdog_ControlRegRemoved) */
        
        #if(!Watchdog_UsingFixedFunction) 
            /* Interrupt State Backup for Critical Region*/
            uint8 Watchdog_interruptState;
        #endif /* (!Watchdog_UsingFixedFunction) */
        
        #if (Watchdog_UsingFixedFunction)
            /* Clear all bits but the enable bit (if it's already set for Timer operation */
            Watchdog_CONTROL &= Watchdog_CTRL_ENABLE;
            
            /* Clear the mode bits for continuous run mode */
            #if (CY_PSOC5A)
                Watchdog_CONTROL2 &= ((uint8)(~Watchdog_CTRL_MODE_MASK));
            #endif /* (CY_PSOC5A) */
            #if (CY_PSOC3 || CY_PSOC5LP)
                Watchdog_CONTROL3 &= ((uint8)(~Watchdog_CTRL_MODE_MASK));                
            #endif /* (CY_PSOC3 || CY_PSOC5LP) */
            /* Check if One Shot mode is enabled i.e. RunMode !=0*/
            #if (Watchdog_RunModeUsed != 0x0u)
                /* Set 3rd bit of Control register to enable one shot mode */
                Watchdog_CONTROL |= Watchdog_ONESHOT;
            #endif /* (Watchdog_RunModeUsed != 0x0u) */
            
            /* Set the IRQ to use the status register interrupts */
            Watchdog_CONTROL2 |= Watchdog_CTRL2_IRQ_SEL;
            
            /* Clear and Set SYNCTC and SYNCCMP bits of RT1 register */
            Watchdog_RT1 &= ((uint8)(~Watchdog_RT1_MASK));
            Watchdog_RT1 |= Watchdog_SYNC;     
                    
            /*Enable DSI Sync all all inputs of the Timer*/
            Watchdog_RT1 &= ((uint8)(~Watchdog_SYNCDSI_MASK));
            Watchdog_RT1 |= Watchdog_SYNCDSI_EN;

        #else
            #if(!Watchdog_ControlRegRemoved)
            /* Set the default compare mode defined in the parameter */
            ctrl = Watchdog_CONTROL & ((uint8)(~Watchdog_CTRL_CMPMODE_MASK));
            Watchdog_CONTROL = ctrl | Watchdog_DEFAULT_COMPARE_MODE;
            
            /* Set the default capture mode defined in the parameter */
            ctrl = Watchdog_CONTROL & ((uint8)(~Watchdog_CTRL_CAPMODE_MASK));
            
            #if( 0 != Watchdog_CAPTURE_MODE_CONF)
                Watchdog_CONTROL = ctrl | Watchdog_DEFAULT_CAPTURE_MODE;
            #else
                Watchdog_CONTROL = ctrl;
            #endif /* 0 != Watchdog_CAPTURE_MODE */ 
            
            #endif /* (!Watchdog_ControlRegRemoved) */
        #endif /* (Watchdog_UsingFixedFunction) */
        
        /* Clear all data in the FIFO's */
        #if (!Watchdog_UsingFixedFunction)
            Watchdog_ClearFIFO();
        #endif /* (!Watchdog_UsingFixedFunction) */
        
        /* Set Initial values from Configuration */
        Watchdog_WritePeriod(Watchdog_INIT_PERIOD_VALUE);
        #if (!(Watchdog_UsingFixedFunction && (CY_PSOC5A)))
            Watchdog_WriteCounter(Watchdog_INIT_COUNTER_VALUE);
        #endif /* (!(Watchdog_UsingFixedFunction && (CY_PSOC5A))) */
        Watchdog_SetInterruptMode(Watchdog_INIT_INTERRUPTS_MASK);
        
        #if (!Watchdog_UsingFixedFunction)
            /* Read the status register to clear the unwanted interrupts */
            (void)Watchdog_ReadStatusRegister();
            /* Set the compare value (only available to non-fixed function implementation */
            Watchdog_WriteCompare(Watchdog_INIT_COMPARE_VALUE);
            /* Use the interrupt output of the status register for IRQ output */
            
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            Watchdog_interruptState = CyEnterCriticalSection();
            
            Watchdog_STATUS_AUX_CTRL |= Watchdog_STATUS_ACTL_INT_EN_MASK;
            
            /* Exit Critical Region*/
            CyExitCriticalSection(Watchdog_interruptState);
            
        #endif /* (!Watchdog_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Watchdog_Enable
********************************************************************************
* Summary:
*     Enable the Counter
* 
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects: 
*   If the Enable mode is set to Hardware only then this function has no effect 
*   on the operation of the counter.
*
*******************************************************************************/
void Watchdog_Enable(void) 
{
    /* Globally Enable the Fixed Function Block chosen */
    #if (Watchdog_UsingFixedFunction)
        Watchdog_GLOBAL_ENABLE |= Watchdog_BLOCK_EN_MASK;
        Watchdog_GLOBAL_STBY_ENABLE |= Watchdog_BLOCK_STBY_EN_MASK;
    #endif /* (Watchdog_UsingFixedFunction) */  
        
    /* Enable the counter from the control register  */
    /* If Fixed Function then make sure Mode is set correctly */
    /* else make sure reset is clear */
    #if(!Watchdog_ControlRegRemoved || Watchdog_UsingFixedFunction)
        Watchdog_CONTROL |= Watchdog_CTRL_ENABLE;                
    #endif /* (!Watchdog_ControlRegRemoved || Watchdog_UsingFixedFunction) */
    
}


/*******************************************************************************
* Function Name: Watchdog_Start
********************************************************************************
* Summary:
*  Enables the counter for operation 
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Global variables:
*  Watchdog_initVar: Is modified when this function is called for the  
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void Watchdog_Start(void) 
{
    if(Watchdog_initVar == 0u)
    {
        Watchdog_Init();
        
        Watchdog_initVar = 1u; /* Clear this bit for Initialization */        
    }
    
    /* Enable the Counter */
    Watchdog_Enable();        
}


/*******************************************************************************
* Function Name: Watchdog_Stop
********************************************************************************
* Summary:
* Halts the counter, but does not change any modes or disable interrupts.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects: If the Enable mode is set to Hardware only then this function
*               has no effect on the operation of the counter.
*
*******************************************************************************/
void Watchdog_Stop(void) 
{
    /* Disable Counter */
    #if(!Watchdog_ControlRegRemoved || Watchdog_UsingFixedFunction)
        Watchdog_CONTROL &= ((uint8)(~Watchdog_CTRL_ENABLE));        
    #endif /* (!Watchdog_ControlRegRemoved || Watchdog_UsingFixedFunction) */
    
    /* Globally disable the Fixed Function Block chosen */
    #if (Watchdog_UsingFixedFunction)
        Watchdog_GLOBAL_ENABLE &= ((uint8)(~Watchdog_BLOCK_EN_MASK));
        Watchdog_GLOBAL_STBY_ENABLE &= ((uint8)(~Watchdog_BLOCK_STBY_EN_MASK));
    #endif /* (Watchdog_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Watchdog_SetInterruptMode
********************************************************************************
* Summary:
* Configures which interrupt sources are enabled to generate the final interrupt
*
* Parameters:  
*  InterruptsMask: This parameter is an or'd collection of the status bits
*                   which will be allowed to generate the counters interrupt.   
*
* Return: 
*  void
*
*******************************************************************************/
void Watchdog_SetInterruptMode(uint8 interruptsMask) 
{
    Watchdog_STATUS_MASK = interruptsMask;
}


/*******************************************************************************
* Function Name: Watchdog_ReadStatusRegister
********************************************************************************
* Summary:
*   Reads the status register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the status register
*
* Side Effects:
*   Status register bits may be clear on read. 
*
*******************************************************************************/
uint8   Watchdog_ReadStatusRegister(void) 
{
    return Watchdog_STATUS;
}


#if(!Watchdog_ControlRegRemoved)
/*******************************************************************************
* Function Name: Watchdog_ReadControlRegister
********************************************************************************
* Summary:
*   Reads the control register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
*******************************************************************************/
uint8   Watchdog_ReadControlRegister(void) 
{
    return Watchdog_CONTROL;
}


/*******************************************************************************
* Function Name: Watchdog_WriteControlRegister
********************************************************************************
* Summary:
*   Sets the bit-field of the control register.  This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
*******************************************************************************/
void    Watchdog_WriteControlRegister(uint8 control) 
{
    Watchdog_CONTROL = control;
}

#endif  /* (!Watchdog_ControlRegRemoved) */


#if (!(Watchdog_UsingFixedFunction && (CY_PSOC5A)))
/*******************************************************************************
* Function Name: Watchdog_WriteCounter
********************************************************************************
* Summary:
*   This funtion is used to set the counter to a specific value
*
* Parameters:  
*  counter:  New counter value. 
*
* Return: 
*  void 
*
*******************************************************************************/
void Watchdog_WriteCounter(uint32 counter) \
                                   
{
    #if(Watchdog_UsingFixedFunction)
        /* assert if block is already enabled */
        CYASSERT (0u == (Watchdog_GLOBAL_ENABLE & Watchdog_BLOCK_EN_MASK));
        /* If block is disabled, enable it and then write the counter */
        Watchdog_GLOBAL_ENABLE |= Watchdog_BLOCK_EN_MASK;
        CY_SET_REG16(Watchdog_COUNTER_LSB_PTR, (uint16)counter);
        Watchdog_GLOBAL_ENABLE &= ((uint8)(~Watchdog_BLOCK_EN_MASK));
    #else
        CY_SET_REG24(Watchdog_COUNTER_LSB_PTR, counter);
    #endif /* (Watchdog_UsingFixedFunction) */
}
#endif /* (!(Watchdog_UsingFixedFunction && (CY_PSOC5A))) */


/*******************************************************************************
* Function Name: Watchdog_ReadCounter
********************************************************************************
* Summary:
* Returns the current value of the counter.  It doesn't matter
* if the counter is enabled or running.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint32) The present value of the counter.
*
*******************************************************************************/
uint32 Watchdog_ReadCounter(void) 
{
    /* Force capture by reading Accumulator */
    /* Must first do a software capture to be able to read the counter */
    /* It is up to the user code to make sure there isn't already captured data in the FIFO */
    #if(Watchdog_UsingFixedFunction)
		(void)CY_GET_REG16(Watchdog_COUNTER_LSB_PTR);
	#else
		(void)CY_GET_REG8(Watchdog_COUNTER_LSB_PTR_8BIT);
	#endif/* (Watchdog_UsingFixedFunction) */
    
    /* Read the data from the FIFO (or capture register for Fixed Function)*/
    #if(Watchdog_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(Watchdog_STATICCOUNT_LSB_PTR));
    #else
        return (CY_GET_REG24(Watchdog_STATICCOUNT_LSB_PTR));
    #endif /* (Watchdog_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Watchdog_ReadCapture
********************************************************************************
* Summary:
*   This function returns the last value captured.
*
* Parameters:  
*  void
*
* Return: 
*  (uint32) Present Capture value.
*
*******************************************************************************/
uint32 Watchdog_ReadCapture(void) 
{
    #if(Watchdog_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(Watchdog_STATICCOUNT_LSB_PTR));
    #else
        return (CY_GET_REG24(Watchdog_STATICCOUNT_LSB_PTR));
    #endif /* (Watchdog_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Watchdog_WritePeriod
********************************************************************************
* Summary:
* Changes the period of the counter.  The new period 
* will be loaded the next time terminal count is detected.
*
* Parameters:  
*  period: (uint32) A value of 0 will result in
*         the counter remaining at zero.  
*
* Return: 
*  void
*
*******************************************************************************/
void Watchdog_WritePeriod(uint32 period) 
{
    #if(Watchdog_UsingFixedFunction)
        CY_SET_REG16(Watchdog_PERIOD_LSB_PTR,(uint16)period);
    #else
        CY_SET_REG24(Watchdog_PERIOD_LSB_PTR, period);
    #endif /* (Watchdog_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Watchdog_ReadPeriod
********************************************************************************
* Summary:
* Reads the current period value without affecting counter operation.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint32) Present period value.
*
*******************************************************************************/
uint32 Watchdog_ReadPeriod(void) 
{
    #if(Watchdog_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(Watchdog_PERIOD_LSB_PTR));
    #else
        return (CY_GET_REG24(Watchdog_PERIOD_LSB_PTR));
    #endif /* (Watchdog_UsingFixedFunction) */
}


#if (!Watchdog_UsingFixedFunction)
/*******************************************************************************
* Function Name: Watchdog_WriteCompare
********************************************************************************
* Summary:
* Changes the compare value.  The compare output will 
* reflect the new value on the next UDB clock.  The compare output will be 
* driven high when the present counter value compares true based on the 
* configured compare mode setting. 
*
* Parameters:  
*  Compare:  New compare value. 
*
* Return: 
*  void
*
*******************************************************************************/
void Watchdog_WriteCompare(uint32 compare) \
                                   
{
    #if(Watchdog_UsingFixedFunction)
        CY_SET_REG16(Watchdog_COMPARE_LSB_PTR, (uint16)compare);
    #else
        CY_SET_REG24(Watchdog_COMPARE_LSB_PTR, compare);
    #endif /* (Watchdog_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Watchdog_ReadCompare
********************************************************************************
* Summary:
* Returns the compare value.
*
* Parameters:  
*  void:
*
* Return: 
*  (uint32) Present compare value.
*
*******************************************************************************/
uint32 Watchdog_ReadCompare(void) 
{
    return (CY_GET_REG24(Watchdog_COMPARE_LSB_PTR));
}


#if (Watchdog_COMPARE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: Watchdog_SetCompareMode
********************************************************************************
* Summary:
*  Sets the software controlled Compare Mode.
*
* Parameters:
*  compareMode:  Compare Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void Watchdog_SetCompareMode(uint8 compareMode) 
{
    /* Clear the compare mode bits in the control register */
    Watchdog_CONTROL &= ((uint8)(~Watchdog_CTRL_CMPMODE_MASK));
    
    /* Write the new setting */
    Watchdog_CONTROL |= compareMode;
}
#endif  /* (Watchdog_COMPARE_MODE_SOFTWARE) */


#if (Watchdog_CAPTURE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: Watchdog_SetCaptureMode
********************************************************************************
* Summary:
*  Sets the software controlled Capture Mode.
*
* Parameters:
*  captureMode:  Capture Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void Watchdog_SetCaptureMode(uint8 captureMode) 
{
    /* Clear the capture mode bits in the control register */
    Watchdog_CONTROL &= ((uint8)(~Watchdog_CTRL_CAPMODE_MASK));
    
    /* Write the new setting */
    Watchdog_CONTROL |= ((uint8)((uint8)captureMode << Watchdog_CTRL_CAPMODE0_SHIFT));
}
#endif  /* (Watchdog_CAPTURE_MODE_SOFTWARE) */


/*******************************************************************************
* Function Name: Watchdog_ClearFIFO
********************************************************************************
* Summary:
*   This function clears all capture data from the capture FIFO
*
* Parameters:  
*  void:
*
* Return: 
*  None
*
*******************************************************************************/
void Watchdog_ClearFIFO(void) 
{

    while(0u != (Watchdog_ReadStatusRegister() & Watchdog_STATUS_FIFONEMP))
    {
        (void)Watchdog_ReadCapture();
    }

}
#endif  /* (!Watchdog_UsingFixedFunction) */


/* [] END OF FILE */

