/*******************************************************************************
* File Name: FrontRED.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_FrontRED_H) /* Pins FrontRED_H */
#define CY_PINS_FrontRED_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "FrontRED_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 FrontRED__PORT == 15 && ((FrontRED__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    FrontRED_Write(uint8 value);
void    FrontRED_SetDriveMode(uint8 mode);
uint8   FrontRED_ReadDataReg(void);
uint8   FrontRED_Read(void);
void    FrontRED_SetInterruptMode(uint16 position, uint16 mode);
uint8   FrontRED_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the FrontRED_SetDriveMode() function.
     *  @{
     */
        #define FrontRED_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define FrontRED_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define FrontRED_DM_RES_UP          PIN_DM_RES_UP
        #define FrontRED_DM_RES_DWN         PIN_DM_RES_DWN
        #define FrontRED_DM_OD_LO           PIN_DM_OD_LO
        #define FrontRED_DM_OD_HI           PIN_DM_OD_HI
        #define FrontRED_DM_STRONG          PIN_DM_STRONG
        #define FrontRED_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define FrontRED_MASK               FrontRED__MASK
#define FrontRED_SHIFT              FrontRED__SHIFT
#define FrontRED_WIDTH              1u

/* Interrupt constants */
#if defined(FrontRED__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in FrontRED_SetInterruptMode() function.
     *  @{
     */
        #define FrontRED_INTR_NONE      (uint16)(0x0000u)
        #define FrontRED_INTR_RISING    (uint16)(0x0001u)
        #define FrontRED_INTR_FALLING   (uint16)(0x0002u)
        #define FrontRED_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define FrontRED_INTR_MASK      (0x01u) 
#endif /* (FrontRED__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define FrontRED_PS                     (* (reg8 *) FrontRED__PS)
/* Data Register */
#define FrontRED_DR                     (* (reg8 *) FrontRED__DR)
/* Port Number */
#define FrontRED_PRT_NUM                (* (reg8 *) FrontRED__PRT) 
/* Connect to Analog Globals */                                                  
#define FrontRED_AG                     (* (reg8 *) FrontRED__AG)                       
/* Analog MUX bux enable */
#define FrontRED_AMUX                   (* (reg8 *) FrontRED__AMUX) 
/* Bidirectional Enable */                                                        
#define FrontRED_BIE                    (* (reg8 *) FrontRED__BIE)
/* Bit-mask for Aliased Register Access */
#define FrontRED_BIT_MASK               (* (reg8 *) FrontRED__BIT_MASK)
/* Bypass Enable */
#define FrontRED_BYP                    (* (reg8 *) FrontRED__BYP)
/* Port wide control signals */                                                   
#define FrontRED_CTL                    (* (reg8 *) FrontRED__CTL)
/* Drive Modes */
#define FrontRED_DM0                    (* (reg8 *) FrontRED__DM0) 
#define FrontRED_DM1                    (* (reg8 *) FrontRED__DM1)
#define FrontRED_DM2                    (* (reg8 *) FrontRED__DM2) 
/* Input Buffer Disable Override */
#define FrontRED_INP_DIS                (* (reg8 *) FrontRED__INP_DIS)
/* LCD Common or Segment Drive */
#define FrontRED_LCD_COM_SEG            (* (reg8 *) FrontRED__LCD_COM_SEG)
/* Enable Segment LCD */
#define FrontRED_LCD_EN                 (* (reg8 *) FrontRED__LCD_EN)
/* Slew Rate Control */
#define FrontRED_SLW                    (* (reg8 *) FrontRED__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define FrontRED_PRTDSI__CAPS_SEL       (* (reg8 *) FrontRED__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define FrontRED_PRTDSI__DBL_SYNC_IN    (* (reg8 *) FrontRED__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define FrontRED_PRTDSI__OE_SEL0        (* (reg8 *) FrontRED__PRTDSI__OE_SEL0) 
#define FrontRED_PRTDSI__OE_SEL1        (* (reg8 *) FrontRED__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define FrontRED_PRTDSI__OUT_SEL0       (* (reg8 *) FrontRED__PRTDSI__OUT_SEL0) 
#define FrontRED_PRTDSI__OUT_SEL1       (* (reg8 *) FrontRED__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define FrontRED_PRTDSI__SYNC_OUT       (* (reg8 *) FrontRED__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(FrontRED__SIO_CFG)
    #define FrontRED_SIO_HYST_EN        (* (reg8 *) FrontRED__SIO_HYST_EN)
    #define FrontRED_SIO_REG_HIFREQ     (* (reg8 *) FrontRED__SIO_REG_HIFREQ)
    #define FrontRED_SIO_CFG            (* (reg8 *) FrontRED__SIO_CFG)
    #define FrontRED_SIO_DIFF           (* (reg8 *) FrontRED__SIO_DIFF)
#endif /* (FrontRED__SIO_CFG) */

/* Interrupt Registers */
#if defined(FrontRED__INTSTAT)
    #define FrontRED_INTSTAT            (* (reg8 *) FrontRED__INTSTAT)
    #define FrontRED_SNAP               (* (reg8 *) FrontRED__SNAP)
    
	#define FrontRED_0_INTTYPE_REG 		(* (reg8 *) FrontRED__0__INTTYPE)
#endif /* (FrontRED__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_FrontRED_H */


/* [] END OF FILE */
