/*******************************************************************************
* File Name: Watchdog_PM.c  
* Version 3.0
*
*  Description:
*    This file provides the power management source code to API for the
*    Counter.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Watchdog.h"

static Watchdog_backupStruct Watchdog_backup;


/*******************************************************************************
* Function Name: Watchdog_SaveConfig
********************************************************************************
* Summary:
*     Save the current user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Watchdog_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void Watchdog_SaveConfig(void) 
{
    #if (!Watchdog_UsingFixedFunction)

        Watchdog_backup.CounterUdb = Watchdog_ReadCounter();

        #if(!Watchdog_ControlRegRemoved)
            Watchdog_backup.CounterControlRegister = Watchdog_ReadControlRegister();
        #endif /* (!Watchdog_ControlRegRemoved) */

    #endif /* (!Watchdog_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Watchdog_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Watchdog_backup:  Variables of this global structure are used to 
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Watchdog_RestoreConfig(void) 
{      
    #if (!Watchdog_UsingFixedFunction)

       Watchdog_WriteCounter(Watchdog_backup.CounterUdb);

        #if(!Watchdog_ControlRegRemoved)
            Watchdog_WriteControlRegister(Watchdog_backup.CounterControlRegister);
        #endif /* (!Watchdog_ControlRegRemoved) */

    #endif /* (!Watchdog_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Watchdog_Sleep
********************************************************************************
* Summary:
*     Stop and Save the user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Watchdog_backup.enableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Watchdog_Sleep(void) 
{
    #if(!Watchdog_ControlRegRemoved)
        /* Save Counter's enable state */
        if(Watchdog_CTRL_ENABLE == (Watchdog_CONTROL & Watchdog_CTRL_ENABLE))
        {
            /* Counter is enabled */
            Watchdog_backup.CounterEnableState = 1u;
        }
        else
        {
            /* Counter is disabled */
            Watchdog_backup.CounterEnableState = 0u;
        }
    #else
        Watchdog_backup.CounterEnableState = 1u;
        if(Watchdog_backup.CounterEnableState != 0u)
        {
            Watchdog_backup.CounterEnableState = 0u;
        }
    #endif /* (!Watchdog_ControlRegRemoved) */
    
    Watchdog_Stop();
    Watchdog_SaveConfig();
}


/*******************************************************************************
* Function Name: Watchdog_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Watchdog_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Watchdog_Wakeup(void) 
{
    Watchdog_RestoreConfig();
    #if(!Watchdog_ControlRegRemoved)
        if(Watchdog_backup.CounterEnableState == 1u)
        {
            /* Enable Counter's operation */
            Watchdog_Enable();
        } /* Do nothing if Counter was disabled before */    
    #endif /* (!Watchdog_ControlRegRemoved) */
    
}


/* [] END OF FILE */
