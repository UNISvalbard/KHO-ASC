/*******************************************************************************
* File Name: DimmerCLK.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_DimmerCLK_H)
#define CY_CLOCK_DimmerCLK_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void DimmerCLK_Start(void) ;
void DimmerCLK_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void DimmerCLK_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void DimmerCLK_StandbyPower(uint8 state) ;
void DimmerCLK_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 DimmerCLK_GetDividerRegister(void) ;
void DimmerCLK_SetModeRegister(uint8 modeBitMask) ;
void DimmerCLK_ClearModeRegister(uint8 modeBitMask) ;
uint8 DimmerCLK_GetModeRegister(void) ;
void DimmerCLK_SetSourceRegister(uint8 clkSource) ;
uint8 DimmerCLK_GetSourceRegister(void) ;
#if defined(DimmerCLK__CFG3)
void DimmerCLK_SetPhaseRegister(uint8 clkPhase) ;
uint8 DimmerCLK_GetPhaseRegister(void) ;
#endif /* defined(DimmerCLK__CFG3) */

#define DimmerCLK_Enable()                       DimmerCLK_Start()
#define DimmerCLK_Disable()                      DimmerCLK_Stop()
#define DimmerCLK_SetDivider(clkDivider)         DimmerCLK_SetDividerRegister(clkDivider, 1u)
#define DimmerCLK_SetDividerValue(clkDivider)    DimmerCLK_SetDividerRegister((clkDivider) - 1u, 1u)
#define DimmerCLK_SetMode(clkMode)               DimmerCLK_SetModeRegister(clkMode)
#define DimmerCLK_SetSource(clkSource)           DimmerCLK_SetSourceRegister(clkSource)
#if defined(DimmerCLK__CFG3)
#define DimmerCLK_SetPhase(clkPhase)             DimmerCLK_SetPhaseRegister(clkPhase)
#define DimmerCLK_SetPhaseValue(clkPhase)        DimmerCLK_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(DimmerCLK__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define DimmerCLK_CLKEN              (* (reg8 *) DimmerCLK__PM_ACT_CFG)
#define DimmerCLK_CLKEN_PTR          ((reg8 *) DimmerCLK__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define DimmerCLK_CLKSTBY            (* (reg8 *) DimmerCLK__PM_STBY_CFG)
#define DimmerCLK_CLKSTBY_PTR        ((reg8 *) DimmerCLK__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define DimmerCLK_DIV_LSB            (* (reg8 *) DimmerCLK__CFG0)
#define DimmerCLK_DIV_LSB_PTR        ((reg8 *) DimmerCLK__CFG0)
#define DimmerCLK_DIV_PTR            ((reg16 *) DimmerCLK__CFG0)

/* Clock MSB divider configuration register. */
#define DimmerCLK_DIV_MSB            (* (reg8 *) DimmerCLK__CFG1)
#define DimmerCLK_DIV_MSB_PTR        ((reg8 *) DimmerCLK__CFG1)

/* Mode and source configuration register */
#define DimmerCLK_MOD_SRC            (* (reg8 *) DimmerCLK__CFG2)
#define DimmerCLK_MOD_SRC_PTR        ((reg8 *) DimmerCLK__CFG2)

#if defined(DimmerCLK__CFG3)
/* Analog clock phase configuration register */
#define DimmerCLK_PHASE              (* (reg8 *) DimmerCLK__CFG3)
#define DimmerCLK_PHASE_PTR          ((reg8 *) DimmerCLK__CFG3)
#endif /* defined(DimmerCLK__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define DimmerCLK_CLKEN_MASK         DimmerCLK__PM_ACT_MSK
#define DimmerCLK_CLKSTBY_MASK       DimmerCLK__PM_STBY_MSK

/* CFG2 field masks */
#define DimmerCLK_SRC_SEL_MSK        DimmerCLK__CFG2_SRC_SEL_MASK
#define DimmerCLK_MODE_MASK          (~(DimmerCLK_SRC_SEL_MSK))

#if defined(DimmerCLK__CFG3)
/* CFG3 phase mask */
#define DimmerCLK_PHASE_MASK         DimmerCLK__CFG3_PHASE_DLY_MASK
#endif /* defined(DimmerCLK__CFG3) */

#endif /* CY_CLOCK_DimmerCLK_H */


/* [] END OF FILE */
