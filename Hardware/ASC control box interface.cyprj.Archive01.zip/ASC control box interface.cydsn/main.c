/* ========================================
 * All-sky video controller interface
 *
 * A very simple small program that will toggle a digital output whenever any
 * character is receiver from the computer.
 *
 * The digital output will "pet a watchdog". As long as there is a happy dog,
 * the output from the controller will keep the ASC shutter open and the
 * intensifier switched on. 
 *
 * In the front panel, there is a green LED that shows whether or not the
 * box is connected to a computer via USB (and it is recognised as a USB serial).
 * The red LED will be on if the shutter should be open and the intensifier powered.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

#define BUFFER_SIZE 64


int main(void)
{

	CyGlobalIntEnable; /* Enable global interrupts. */
    PWM_dimmer_Start();
	
    Watchdog_Start();
    
    LED_Write(0u);
    Control_out_Write(0u);
    FrontGREEN_Write(0u);
    
	USBUART_Start(0, USBUART_5V_OPERATION);
	while(USBUART_GetConfiguration() == 0) {}  // Wait for connection
	USBUART_CDC_Init();
    FrontGREEN_Write(1u); // Show there is a connection to the computer
    
    for (;;) {
	    if (USBUART_IsConfigurationChanged()) {
            FrontGREEN_Write(0u); // No connection yet

            if (USBUART_GetConfiguration()) {
			    USBUART_CDC_Init();
               	LED_Write(0u);
                Control_out_Write(0u);
	            FrontGREEN_Write(1u);
            }
	    }

        /* Toggle the LED on the PCB whenever we get something sent from the computer */
        
	    if (USBUART_DataIsReady()) {
		    USBUART_GetChar();
		    LED_Write(!LED_Read()); 
	        Control_out_Write(!Control_out_Read());
            ShutterOpen_Write(1u); /* Pet the watchdog */
	    }
    }
}
